using UnityEngine;
using UnityEngine.SceneManagement;
using Photon.Pun;

public class LoadingGame : MonoBehaviourPunCallbacks
{
    public string lobbySceneName = "Lobby";

    void Start()
    {
        if (!PhotonNetwork.IsConnected)
        {
            Debug.Log("[LoadingGame] Connecting to Photon...");
            PhotonNetwork.ConnectUsingSettings();
        }
        else
        {
            Debug.Log("[LoadingGame] Already connected.");
        }
        PhotonNetwork.AutomaticallySyncScene = true;
    }

    public override void OnConnectedToMaster()
    {
        Debug.Log($"[LoadingGame] OnConnectedToMaster. ActiveScene={SceneManager.GetActiveScene().name} SceneLoadGuard={SceneLoadGuard.IsSceneLoading}");
        if (SceneManager.GetActiveScene().name == "Loading" && !SceneLoadGuard.IsSceneLoading)
        {
            Debug.Log("[LoadingGame] Loading -> Menu");
            SceneManager.LoadScene(lobbySceneName);
        }
        else
        {
            Debug.Log("[LoadingGame] Skipping Menu load (not in Loading scene or guard active).");
        }
    }
}

