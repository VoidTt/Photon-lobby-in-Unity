// SceneLoadGuard.cs
using System;
using UnityEngine;

public static class SceneLoadGuard
{
    public static bool IsSceneLoading = false;
    public static string Reason = null;
    public static string InitiatorStack = null;

    public static void SetLoading(string reason)
    {
        if (IsSceneLoading) return;
        IsSceneLoading = true;
        Reason = reason ?? "unknown";
        try
        {
            InitiatorStack = Environment.StackTrace;
        }
        catch (Exception ex)
        {
            InitiatorStack = "Exception reading stack: " + ex;
        }
        Debug.Log($"[SceneLoadGuard] SetLoading reason='{Reason}'\nStack:\n{InitiatorStack}");
    }

    public static void ClearLoading()
    {
        if (IsSceneLoading)
        { 
            Debug.Log($"[SceneLoadGuard] ClearLoading called (previous reason='{Reason}')");
        }
        IsSceneLoading = false;
        Reason = null;
    }
}
