using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.SceneManagement;
using Hashtable = ExitGames.Client.Photon.Hashtable;
using ExitGames.Client.Photon;

public class RoomManager : MonoBehaviourPunCallbacks, IOnEventCallback
{
    [Header("UI")]
    [SerializeField] private TextMeshProUGUI hostNameText;
    [SerializeField] private TextMeshProUGUI playersCountText;
    [SerializeField] private GameObject[] slotObjects;
    [SerializeField] private TextMeshProUGUI[] slotTexts;
    [SerializeField] private Button startGameButton;
    [SerializeField] private Button leaveRoomButton;
    [SerializeField] private string lobbySceneName = "Lobby";
    [SerializeField] private string roomSceneName = "Room";

    const int MaxSlots = 12;
    const string PREF_LAST_LEFT = "Lobby_LastLeftTime";

    const byte EV_REQUEST_SLOT = 1;
    const byte EV_ASSIGN_SLOT = 2;
    const byte EV_RELEASE_SLOT = 3;

    bool isForceClosingHandled = false;

    new void OnEnable()
    {
        PhotonNetwork.AddCallbackTarget(this);
    }

    new void OnDisable()
    {
        PhotonNetwork.RemoveCallbackTarget(this);
    }

    void Start()
    {
        PhotonNetwork.AutomaticallySyncScene = true;

        if (slotObjects == null || slotObjects.Length != MaxSlots ||
            slotTexts == null || slotTexts.Length != MaxSlots)
            Debug.LogWarning($"[RoomManager] Slot arrays should be length {MaxSlots}.");

        for (int i = 0; i < Mathf.Min(MaxSlots, slotObjects?.Length ?? 0); i++)
            if (slotObjects[i] != null) slotObjects[i].SetActive(false);

        for (int i = 0; i < Mathf.Min(MaxSlots, slotTexts?.Length ?? 0); i++)
            if (slotTexts[i] != null) slotTexts[i].text = string.Empty;

        if (startGameButton != null) startGameButton.onClick.AddListener(OnStartGame);
        if (leaveRoomButton != null) leaveRoomButton.onClick.AddListener(OnLeave);

        if (PhotonNetwork.InRoom)
        {
            InitFromRoom();
            if (PhotonNetwork.IsMasterClient)
            {
                EnsureMasterHasSlotForActor(PhotonNetwork.LocalPlayer.ActorNumber);
            }
            else
            {
                RequestSlotFromMaster();
            }
        }
    }

    void OnDestroy()
    {
        if (startGameButton != null) startGameButton.onClick.RemoveListener(OnStartGame);
        if (leaveRoomButton != null) leaveRoomButton.onClick.RemoveListener(OnLeave);
    }

    void InitFromRoom()
    {
        ReadCreator();
        RefreshUI();
        UpdateStartButton();
    }

    void ReadCreator()
    {
        if (!PhotonNetwork.InRoom) return;
        var props = PhotonNetwork.CurrentRoom.CustomProperties;
        string creator = null;
        if (props != null && props.ContainsKey("creatorName")) creator = props["creatorName"]?.ToString();
        if (string.IsNullOrEmpty(creator) && PhotonNetwork.MasterClient != null) creator = PhotonNetwork.MasterClient.NickName;
        if (hostNameText != null) hostNameText.text = $"���������: {creator}";
    }

    void RequestSlotFromMaster()
    {
        if (!PhotonNetwork.InRoom) return;
        if (PhotonNetwork.IsMasterClient)
        {
            EnsureMasterHasSlotForActor(PhotonNetwork.LocalPlayer.ActorNumber);
            return;
        }

        var options = new RaiseEventOptions
        {
            TargetActors = new int[] { PhotonNetwork.MasterClient.ActorNumber }
        };
        PhotonNetwork.RaiseEvent(EV_REQUEST_SLOT, null, options, SendOptions.SendReliable);
        Debug.Log("[RoomManager] Requested slot from master.");
    }

    private int EnsureMasterHasSlotForActor(int actorNumber)
    {
        if (!PhotonNetwork.InRoom || !PhotonNetwork.IsMasterClient) return -1;

        var roomProps = PhotonNetwork.CurrentRoom.CustomProperties;
        for (int i = 1; i <= MaxSlots; i++)
        {
            string key = $"slot_{i}";
            if (roomProps.ContainsKey(key))
            {
                try
                {
                    int val = Convert.ToInt32(roomProps[key]);
                    if (val == actorNumber)
                    {
                        SendAssignSlotEvent(actorNumber, i);
                        RefreshUI();
                        return i;
                    }
                }
                catch { }
            }
        }

        for (int i = 1; i <= MaxSlots; i++)
        {
            string key = $"slot_{i}";
            bool missing = !roomProps.ContainsKey(key);
            int val = 0;
            if (!missing)
            {
                try { val = Convert.ToInt32(roomProps[key]); } catch { val = 0; }
            }

            if (missing || val == 0)
            {
                var set = new Hashtable { { key, actorNumber } };
                PhotonNetwork.CurrentRoom.SetCustomProperties(set);
                Debug.Log($"[RoomManager] Master assigned actor {actorNumber} -> slot_{i}");
                SendAssignSlotEvent(actorNumber, i);
                RefreshUI();
                return i;
            }
        }

        Debug.LogWarning("[RoomManager] No free slots available for actor " + actorNumber);
        SendAssignSlotEvent(actorNumber, 0);
        return 0;
    }

    private void SendAssignSlotEvent(int targetActor, int slotIndex)
    {
        var payload = slotIndex;
        var options = new RaiseEventOptions { TargetActors = new int[] { targetActor } };
        PhotonNetwork.RaiseEvent(EV_ASSIGN_SLOT, payload, options, SendOptions.SendReliable);
    }

    private void MasterReleaseSlotsForActor(int actorNumber)
    {
        if (!PhotonNetwork.InRoom || !PhotonNetwork.IsMasterClient) return;

        var roomProps = PhotonNetwork.CurrentRoom.CustomProperties;
        var toClear = new Hashtable();
        bool any = false;
        for (int i = 1; i <= MaxSlots; i++)
        {
            string key = $"slot_{i}";
            if (!roomProps.ContainsKey(key)) continue;
            try
            {
                int v = Convert.ToInt32(roomProps[key]);
                if (v == actorNumber)
                {
                    toClear[key] = 0;
                    any = true;
                }
            }
            catch { }
        }
        if (any)
        {
            PhotonNetwork.CurrentRoom.SetCustomProperties(toClear);
            Debug.Log($"[RoomManager] Master cleared slots for actor {actorNumber}");
        }
    }



    // ----------------IOnEventCallback----------------


    public void OnEvent(EventData photonEvent)
    {
        byte code = photonEvent.Code;
        if (code == EV_REQUEST_SLOT)
        {
            if (!PhotonNetwork.IsMasterClient) return;
            int requester = photonEvent.Sender;
            EnsureMasterHasSlotForActor(requester);
        }
        else if (code == EV_ASSIGN_SLOT)
        {
            int slotIndex = 0;
            try { slotIndex = Convert.ToInt32(photonEvent.CustomData); } catch { slotIndex = 0; }
            HandleAssignedSlot(slotIndex);
        }
        else if (code == EV_RELEASE_SLOT)
        {
            if (!PhotonNetwork.IsMasterClient) return;
            int requester = photonEvent.Sender;
            MasterReleaseSlotsForActor(requester);
        }
    }

    private void HandleAssignedSlot(int slotIndex)
    {
        try
        {
            PhotonNetwork.LocalPlayer.SetCustomProperties(new Hashtable { { "slot", slotIndex } });
        }
        catch { }

        if (slotIndex <= 0)
        {
            Debug.LogWarning("[RoomManager] Assigned no slot (room full or error).");
        }
        else
        {
            Debug.Log("[RoomManager] Assigned slot: " + slotIndex);
        }
        RefreshUI();
    }




    void RefreshUI()
    {
        if (!PhotonNetwork.InRoom)
        {
            for (int i = 0; i < Mathf.Min(slotObjects?.Length ?? 0, MaxSlots); i++)
            {
                if (slotObjects[i] != null) slotObjects[i].SetActive(false);
            }
            for (int i = 0; i < Mathf.Min(slotTexts?.Length ?? 0, MaxSlots); i++)
            {
                if (slotTexts[i] != null) slotTexts[i].text = string.Empty;
            }
            if (playersCountText != null) playersCountText.text = $"0/{MaxSlots}";
            return;
        }

        var roomProps = PhotonNetwork.CurrentRoom.CustomProperties;

        for (int i = 1; i <= MaxSlots; i++)
        {
            string key = $"slot_{i}";
            int actor = 0;
            if (roomProps != null && roomProps.ContainsKey(key))
            {
                try { actor = Convert.ToInt32(roomProps[key]); } catch { actor = 0; }
            }
            int idx = i - 1;

            if (actor > 0)
            {
                var player = PhotonNetwork.PlayerList.FirstOrDefault(p => p.ActorNumber == actor);
                string name = player != null ? (string.IsNullOrEmpty(player.NickName) ? $"Player_{actor}" : player.NickName) : $"Player_{actor}";
                if (slotObjects != null && idx < slotObjects.Length && slotObjects[idx] != null) slotObjects[idx].SetActive(true);
                if (slotTexts != null && idx < slotTexts.Length && slotTexts[idx] != null) slotTexts[idx].text = name;
            }
            else
            {
                if (slotObjects != null && idx < slotObjects.Length && slotObjects[idx] != null) slotObjects[idx].SetActive(false);
                if (slotTexts != null && idx < slotTexts.Length && slotTexts[idx] != null) slotTexts[idx].text = string.Empty;
            }
        }

        if (playersCountText != null && PhotonNetwork.CurrentRoom != null)
        {
            int cnt = PhotonNetwork.CurrentRoom.PlayerCount;
            int max = PhotonNetwork.CurrentRoom.MaxPlayers;
            playersCountText.text = $"{cnt}/{max}";
        }
    }

    void UpdateStartButton()
    {
        if (startGameButton == null || !PhotonNetwork.InRoom) return;
        int creatorActor = -1;
        var props = PhotonNetwork.CurrentRoom.CustomProperties;
        if (props != null && props.ContainsKey("creatorActor")) { try { creatorActor = Convert.ToInt32(props["creatorActor"]); } catch { } }
        startGameButton.interactable = PhotonNetwork.LocalPlayer.ActorNumber == creatorActor;
    }

    void OnStartGame()
    {
        if (!PhotonNetwork.InRoom) return;
        var props = PhotonNetwork.CurrentRoom.CustomProperties;
        int creatorActor = -1;
        if (props != null && props.ContainsKey("creatorActor")) { try { creatorActor = Convert.ToInt32(props["creatorActor"]); } catch { } }
        if (PhotonNetwork.LocalPlayer.ActorNumber != creatorActor) { Debug.LogWarning("Only creator can start."); return; }

        PhotonNetwork.CurrentRoom.IsOpen = false;
        PhotonNetwork.CurrentRoom.IsVisible = false;
        PhotonNetwork.CurrentRoom.SetCustomProperties(new Hashtable { { "gameStarted", true } });

        SceneLoadGuard.SetLoading("RoomManager OnStartGame");
        PhotonNetwork.LoadLevel(roomSceneName);
    }

    void OnLeave()
    {
        if (!PhotonNetwork.InRoom)
        {
            SceneManager.LoadScene(lobbySceneName);
            return;
        }

        PlayerPrefs.SetFloat(PREF_LAST_LEFT, Time.time);
        PlayerPrefs.Save();

        SceneLoadGuard.ClearLoading();

        int creatorActor = -1;
        var props = PhotonNetwork.CurrentRoom.CustomProperties;
        if (props != null && props.ContainsKey("creatorActor")) { try { creatorActor = Convert.ToInt32(props["creatorActor"]); } catch { } }

        if (PhotonNetwork.LocalPlayer.ActorNumber == creatorActor)
        {
            Debug.Log("[RoomManager] Creator initiating force-close.");

            PhotonNetwork.CurrentRoom.IsOpen = false;
            PhotonNetwork.CurrentRoom.IsVisible = false;

            var clearAll = new Hashtable();
            for (int i = 1; i <= MaxSlots; i++) clearAll[$"slot_{i}"] = 0;
            PhotonNetwork.CurrentRoom.SetCustomProperties(clearAll);

            var set = new Hashtable { { "forceClose", true }, { "closedBy", PhotonNetwork.LocalPlayer.ActorNumber } };
            PhotonNetwork.CurrentRoom.SetCustomProperties(set);

            PhotonNetwork.LocalPlayer.SetCustomProperties(new Hashtable { { "slot", 0 } });

            PhotonNetwork.LeaveRoom();
            return;
        }
        else
        {
            if (PhotonNetwork.IsMasterClient)
            {
                MasterReleaseSlotsForActor(PhotonNetwork.LocalPlayer.ActorNumber);
            }
            else
            {
                var options = new RaiseEventOptions { TargetActors = new int[] { PhotonNetwork.MasterClient.ActorNumber } };
                PhotonNetwork.RaiseEvent(EV_RELEASE_SLOT, null, options, SendOptions.SendReliable);
            }

            PhotonNetwork.LocalPlayer.SetCustomProperties(new Hashtable { { "slot", 0 } });
            PhotonNetwork.LeaveRoom();
            return;
        }
    }

    public override void OnJoinedRoom()
    {
        Debug.Log("[RoomManager] OnJoinedRoom");
        InitFromRoom();

        if (PhotonNetwork.IsMasterClient)
        {
            EnsureMasterHasSlotForActor(PhotonNetwork.LocalPlayer.ActorNumber);
        }
        else
        {
            RequestSlotFromMaster();
        }
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        RefreshUI();
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        if (PhotonNetwork.IsMasterClient)
        {
            MasterReleaseSlotsForActor(otherPlayer.ActorNumber);
        }
        RefreshUI();
    }

    public override void OnRoomPropertiesUpdate(Hashtable propertiesThatChanged)
    {
        bool need = propertiesThatChanged != null &&
                    propertiesThatChanged.Keys.Cast<object>()
                    .Any(k => k.ToString().StartsWith("slot_") || k.Equals("creatorActor") || k.Equals("creatorName") || k.Equals("forceClose") || k.Equals("gameStarted"));

        if (need) RefreshUI();

        if (propertiesThatChanged != null && propertiesThatChanged.ContainsKey("forceClose"))
        {
            bool shouldClose = false;
            try { shouldClose = Convert.ToBoolean(propertiesThatChanged["forceClose"]); } catch { shouldClose = false; }
            if (shouldClose && !isForceClosingHandled)
            {
                isForceClosingHandled = true;
                Debug.Log("[RoomManager] forceClose detected -> leaving room.");
                PlayerPrefs.SetFloat(PREF_LAST_LEFT, Time.time);
                PlayerPrefs.Save();
                PhotonNetwork.LocalPlayer.SetCustomProperties(new Hashtable { { "slot", 0 } });
                SceneLoadGuard.ClearLoading();
                PhotonNetwork.LeaveRoom();
            }
        }
    }

    public override void OnLeftRoom()
    {
        SceneManager.LoadScene(lobbySceneName);
    }

    public override void OnMasterClientSwitched(Player newMasterClient)
    {
        if (PhotonNetwork.IsMasterClient)
        {
            EnsureMasterHasSlotForActor(PhotonNetwork.LocalPlayer.ActorNumber);
            SweepAndFixDuplicates();
        }
        RefreshUI();
    }

    private void SweepAndFixDuplicates()
    {
        if (!PhotonNetwork.IsMasterClient || !PhotonNetwork.InRoom) return;

        var roomProps = PhotonNetwork.CurrentRoom.CustomProperties;
        var actorToSlots = new System.Collections.Generic.Dictionary<int, System.Collections.Generic.List<int>>();
        for (int s = 1; s <= MaxSlots; s++)
        {
            string key = $"slot_{s}";
            if (!roomProps.ContainsKey(key)) continue;
            try
            {
                int actor = Convert.ToInt32(roomProps[key]);
                if (actor <= 0) continue;
                if (!actorToSlots.ContainsKey(actor)) actorToSlots[actor] = new System.Collections.Generic.List<int>();
                actorToSlots[actor].Add(s);
            }
            catch { }
        }

        var toClear = new Hashtable();
        foreach (var kv in actorToSlots)
        {
            var list = kv.Value.OrderBy(x => x).ToList();
            for (int i = 1; i < list.Count; i++)
            {
                toClear[$"slot_{list[i]}"] = 0;
            }
        }
        if (toClear.Count > 0)
        {
            PhotonNetwork.CurrentRoom.SetCustomProperties(toClear);
            Debug.Log("[RoomManager] Master swept duplicates and cleared extras.");
            RefreshUI();
        }
    }
}
