using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;


public class StartGame : MonoBehaviourPunCallbacks
{
    [SerializeField] private Button startButton;

    //-------------------------------

    [SerializeField] private string sceneName = ""; //!! �������� ����� ������� ������ ���������(The name of the scene you want to run) !! ����� ������� � inspector

    //--------------------------------

    [SerializeField] private int countdownSeconds = 0;
    [SerializeField] private TextMeshProUGUI countdownText;

    [SerializeField] private bool setRoomClosedWhenStarting = true;
    [SerializeField] private bool setGameStartedFlag = true;

    private Coroutine countdownCoroutine;

    void Start()
    {
        PhotonNetwork.AutomaticallySyncScene = true;

        if (startButton != null)
        {
            startButton.onClick.AddListener(OnStartPressed);
        }

        UpdateStartButtonState();
        if (countdownText != null) countdownText.gameObject.SetActive(false);
    }

    void OnDestroy()
    {
        if (startButton != null) startButton.onClick.RemoveListener(OnStartPressed);
    }

    void UpdateStartButtonState()
    {
        if (startButton == null) return;

        if (!PhotonNetwork.InRoom)
        {
            startButton.interactable = false;
            return;
        }

        int creatorActor = GetCreatorActorFromRoom();
        bool amCreator = PhotonNetwork.LocalPlayer != null && PhotonNetwork.LocalPlayer.ActorNumber == creatorActor;
        startButton.interactable = amCreator;
    }

    int GetCreatorActorFromRoom()
    {
        if (!PhotonNetwork.InRoom) return -1;
        var props = PhotonNetwork.CurrentRoom.CustomProperties;
        if (props != null && props.ContainsKey("creatorActor"))
        {
            try { return Convert.ToInt32(props["creatorActor"]); }
            catch { return -1; }
        }
        return PhotonNetwork.MasterClient != null ? PhotonNetwork.MasterClient.ActorNumber : -1;
    }

    void OnStartPressed()
    {
        if (!PhotonNetwork.InRoom)
        {
            Debug.LogWarning("[GameStarter] Not in room � can't start.");
            return;
        }

        int creatorActor = GetCreatorActorFromRoom();
        if (PhotonNetwork.LocalPlayer.ActorNumber != creatorActor)
        {
            Debug.LogWarning("[GameStarter] Only the creator can start the game.");
            UpdateStartButtonState();
            return;
        }
        if (startButton != null) startButton.interactable = false;

        if (countdownSeconds > 0 && countdownText != null)
        {
            if (countdownCoroutine != null) StopCoroutine(countdownCoroutine);
            countdownCoroutine = StartCoroutine(CountdownAndStart(countdownSeconds));
        }
        else
        {
            StartGameImmediate();
        }
    }

    IEnumerator CountdownAndStart(int seconds)
    {
        if (countdownText != null)
        {
            countdownText.gameObject.SetActive(true);
        }

        int remaining = seconds;
        while (remaining > 0)
        {
            if (countdownText != null)
                countdownText.text = $"���� �������� ����� {remaining}...";
            yield return new WaitForSeconds(1f);
            remaining--;
        }

        if (countdownText != null) countdownText.gameObject.SetActive(false);
        StartGameImmediate();
    }

    void StartGameImmediate()
    {
        if (!PhotonNetwork.InRoom)
        {
            Debug.LogWarning("[GameStarter] Not in room at StartGameImmediate.");
            return;
        }
        // Closing the room
        if (setRoomClosedWhenStarting && PhotonNetwork.CurrentRoom != null)
        {
            PhotonNetwork.CurrentRoom.IsOpen = false;
            PhotonNetwork.CurrentRoom.IsVisible = false;
        }

        if (setGameStartedFlag)
        {
            ExitGames.Client.Photon.Hashtable props = new ExitGames.Client.Photon.Hashtable { { "gameStarted", true } };
            PhotonNetwork.CurrentRoom.SetCustomProperties(props);
        }

        Debug.Log("[GameStarter] Creator starting game. Loading scene: " + sceneName);
        PhotonNetwork.LoadLevel(sceneName);
    }
    public override void OnRoomPropertiesUpdate(ExitGames.Client.Photon.Hashtable propertiesThatChanged)
    {
        UpdateStartButtonState();
    }

    public override void OnJoinedRoom()
    {
        UpdateStartButtonState();
    }

    public override void OnLeftRoom()
    {
        if (countdownCoroutine != null) StopCoroutine(countdownCoroutine);
        if (countdownText != null) countdownText.gameObject.SetActive(false);
    }

    // When changing a host, we find a new host
    public override void OnMasterClientSwitched(Player newMasterClient)
    {
        UpdateStartButtonState();
    }
}