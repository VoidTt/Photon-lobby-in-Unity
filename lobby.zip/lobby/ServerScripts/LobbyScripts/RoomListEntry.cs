using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;
using ExitGames.Client.Photon;
using System.Security.Cryptography;
using System.Text;


public class RoomListEntry : MonoBehaviour
{
    [Header("UI refs")]
    [SerializeField] private TextMeshProUGUI roomNameText;
    [SerializeField] private TextMeshProUGUI playersText;
    [SerializeField] private Button joinButton;

    [SerializeField] private TMP_InputField passwordToJoinInput;
    [SerializeField] private Button passwordSubmitButton;
    [SerializeField] private TextMeshProUGUI passwordErrorText;


    private string roomName;
    private string storedPwHash = null;
    private bool pwProtected = false;
    private Action<string> onJoinCallback;

    void Awake()
    {
        if (GetComponent<RectTransform>() == null)
            gameObject.AddComponent<RectTransform>();


        if (passwordToJoinInput != null) passwordToJoinInput.gameObject.SetActive(false);
        if (passwordErrorText != null) passwordErrorText.gameObject.SetActive(false);

        if (joinButton != null) joinButton.onClick.AddListener(OnJoinPressed);
        if (passwordSubmitButton != null) passwordSubmitButton.onClick.AddListener(OnPasswordSubmit);

        if (passwordToJoinInput != null)
        {
            passwordToJoinInput.onSubmit.AddListener((s) =>
            {
                OnPasswordSubmit();
            });
        }
    }

    void OnDestroy()
    {
        if (joinButton != null) joinButton.onClick.RemoveListener(OnJoinPressed);
        if (passwordSubmitButton != null) passwordSubmitButton.onClick.RemoveListener(OnPasswordSubmit);

        if (passwordToJoinInput != null)
        {
            try { passwordToJoinInput.onSubmit.RemoveAllListeners(); } catch { }
        }
    }

    public void SetInfo(string name, int players, int maxPlayers, Action<string> onJoin, Hashtable customProps = null)
    {
        roomName = name;
        onJoinCallback = onJoin;

        Debug.Log($"[RoomListEntry] SetInfo '{name}' players {players}/{maxPlayers}");

        if (roomNameText != null) roomNameText.text = name;
        if (playersText != null) playersText.text = $"{players}/{maxPlayers}";
        if (passwordErrorText != null) passwordErrorText.gameObject.SetActive(false);

        if (customProps != null)
        {
            bool prevProtected = pwProtected;
            string prevHash = storedPwHash;

            if (customProps.ContainsKey("pwProtected"))
            {
                try { pwProtected = Convert.ToBoolean(customProps["pwProtected"]); }
                catch { pwProtected = false; }
            }
            if (customProps.ContainsKey("pwHash"))
            {
                var hv = customProps["pwHash"];
                storedPwHash = hv != null ? hv.ToString() : null;
            }

            Debug.Log($"[RoomListEntry] '{name}' customProps -> pwProtected={pwProtected} hashPresent={(storedPwHash != null)} prevProtected={prevProtected}");
        }
        else
        {
            Debug.Log($"[RoomListEntry] '{name}' customProps is null; current pwProtected={pwProtected} hashPresent={(storedPwHash != null)}");
        }
    }

    private void OnJoinPressed()
    {
        Debug.Log($"[RoomListEntry] OnJoinPressed '{roomName}' protected={pwProtected}");

        if (!pwProtected)
        {
            onJoinCallback?.Invoke(roomName);
            return;
        }

        if (passwordToJoinInput != null)
        {
            passwordToJoinInput.gameObject.SetActive(true);
            passwordToJoinInput.ActivateInputField();
            if (passwordErrorText != null) passwordErrorText.gameObject.SetActive(false);
        }
        else
        {
            Debug.LogWarning("[RoomListEntry] passwordToJoinInput is not assigned in prefab; cannot enter password.");
        }
    }



    private void OnPasswordSubmit()
    {
        if (passwordToJoinInput == null)
        {
            ShowPasswordError("���� ������ �� ���������");
            return;
        }

        string attempt = passwordToJoinInput.text ?? string.Empty;
        if (string.IsNullOrEmpty(attempt))
        {
            ShowPasswordError("������� ������");
            return;
        }

        if (!pwProtected)
        {
            onJoinCallback?.Invoke(roomName);
            return;
        }

        if (storedPwHash == null)
        {
            ShowPasswordError("��� ������ ��� �� �������. ���������.");
            Debug.LogWarning($"[RoomListEntry] storedPwHash is null for room '{roomName}' � can't validate now.");
            return;
        }

        string attemptHash = ComputeSHA256Hash(attempt);
        Debug.Log($"[RoomListEntry] Password attempt for '{roomName}': hash={attemptHash} compareTo={storedPwHash}");

        if (string.Equals(attemptHash, storedPwHash, StringComparison.OrdinalIgnoreCase))
        {
            if (passwordErrorText != null) passwordErrorText.gameObject.SetActive(false);
            passwordToJoinInput.gameObject.SetActive(false);
            onJoinCallback?.Invoke(roomName);
        }
        else
        {
            ShowPasswordError("�������� ������");
        }
    }

    private void ShowPasswordError(string msg)
    {
        Debug.LogWarning($"[RoomListEntry] Password error for '{roomName}': {msg}");
        if (passwordErrorText != null)
        {
            passwordErrorText.text = msg;
            passwordErrorText.gameObject.SetActive(true);
        }
    }


    private string ComputeSHA256Hash(string input)
    {
        if (string.IsNullOrEmpty(input)) return null;
        using (var sha = SHA256.Create())
        {
            var bytes = Encoding.UTF8.GetBytes(input);
            var hash = sha.ComputeHash(bytes);
            var sb = new StringBuilder(hash.Length * 2);
            foreach (var b in hash) sb.AppendFormat("{0:x2}", b);
            return sb.ToString();
        }
    }
}
