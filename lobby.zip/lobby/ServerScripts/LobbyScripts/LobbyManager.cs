using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using Hashtable = ExitGames.Client.Photon.Hashtable;

public class LobbyManager : MonoBehaviourPunCallbacks
{
    [Header("UI (bind in inspector)")]
    [SerializeField] private GameObject roomEntryPrefab;
    [SerializeField] private Transform contentParent;

    [SerializeField] private TMP_InputField createRoomInput;
    [SerializeField] private Button createRoomButton;
    [SerializeField] private TMP_InputField createRoomPasswordInput;

    [SerializeField] private Button createPasswordToggleButton;
    [SerializeField] private GameObject createPasswordIndicator;

    [SerializeField] private TextMeshProUGUI createCooldownText;
    [SerializeField] private float createCooldownSeconds = 300f;



    private readonly Dictionary<string, GameObject> roomEntries = new Dictionary<string, GameObject>();
    private string pendingRoomToCreate = null;
    private GameObject pendingLocalEntry = null;
    private bool createPasswordEnabled = false;

    private const string PREF_LAST_LEFT = "Lobby_LastLeftTime";

    private float lastLeftTime = -99999f;
    private Coroutine cooldownCoroutine = null;

    void Start()
    {
        if (createRoomPasswordInput != null) createRoomPasswordInput.gameObject.SetActive(false);
        if (createPasswordIndicator != null) createPasswordIndicator.SetActive(false);

        if (createPasswordToggleButton != null) createPasswordToggleButton.onClick.AddListener(ToggleCreatePassword);

        if (createRoomButton != null)
        {
            createRoomButton.onClick.RemoveAllListeners();
            createRoomButton.onClick.AddListener(CreateRoomFromInput);
            createRoomButton.interactable = false;
        }

        if (PlayerPrefs.HasKey(PREF_LAST_LEFT))
        {
            float val = PlayerPrefs.GetFloat(PREF_LAST_LEFT, -99999f);
            if (val > 0f)
            {
                lastLeftTime = val;
                PlayerPrefs.DeleteKey(PREF_LAST_LEFT);
                PlayerPrefs.Save();
                Debug.Log("[Lobby] Detected persisted lastLeftTime -> " + lastLeftTime);
            }
        }
        UpdateCooldownTextImmediate();

        if (!PhotonNetwork.IsConnected)
        {
            Debug.Log("[Lobby] Connecting to Photon...");
            PhotonNetwork.ConnectUsingSettings();
        }
        else if (PhotonNetwork.IsConnectedAndReady)
        {
            PhotonNetwork.JoinLobby(TypedLobby.Default);
        }
    }




    void OnDestroy()
    {
        if (createPasswordToggleButton != null) createPasswordToggleButton.onClick.RemoveListener(ToggleCreatePassword);
        if (createRoomButton != null) createRoomButton.onClick.RemoveListener(CreateRoomFromInput);
    }

    private void ToggleCreatePassword()
    {
        createPasswordEnabled = !createPasswordEnabled;
        if (createRoomPasswordInput != null) createRoomPasswordInput.gameObject.SetActive(createPasswordEnabled);
        if (createPasswordIndicator != null) createPasswordIndicator.SetActive(createPasswordEnabled);
    }

    public override void OnConnectedToMaster()
    {
        Debug.Log("[Lobby] OnConnectedToMaster -> joining default lobby");
        PhotonNetwork.JoinLobby(TypedLobby.Default);

        if (!string.IsNullOrEmpty(pendingRoomToCreate))
        {
            Debug.Log("[Lobby] Creating queued room: " + pendingRoomToCreate);
            CreateRoomInternal(pendingRoomToCreate, false, null);
            pendingRoomToCreate = null;
        }
    }

    public override void OnJoinedLobby()
    {
        Debug.Log("[Lobby] OnJoinedLobby - lobby ready");
        if (createRoomButton != null) createRoomButton.interactable = true;
    }

    public override void OnLeftLobby()
    {
        Debug.Log("[Lobby] Left lobby");
        if (createRoomButton != null) createRoomButton.interactable = false;
        ClearAllRoomEntries();
    }

    public override void OnRoomListUpdate(List<RoomInfo> roomList)
    {
        Debug.Log($"[Lobby] OnRoomListUpdate called. count={roomList?.Count ?? 0}");

        if (roomList == null || roomList.Count == 0)
        {
            return;
        }

        foreach (var info in roomList)
        {
            if (info == null) continue;

            string name = info.Name;
            Debug.Log($"[Lobby] Room update: {name} Players={info.PlayerCount}/{info.MaxPlayers} Removed={info.RemovedFromList}");

            if (info.RemovedFromList)
            {
                if (roomEntries.TryGetValue(name, out GameObject go) && go != null)
                {
                    Destroy(go);
                }
                roomEntries.Remove(name);
                continue;
            }

            if (roomEntries.TryGetValue(name, out GameObject existing) && existing != null)
            {
                var entry = existing.GetComponent<RoomListEntry>();
                if (entry != null) entry.SetInfo(name, info.PlayerCount, info.MaxPlayers, OnJoinButtonClicked, info.CustomProperties);
            }
            else
            {
                if (roomEntryPrefab == null || contentParent == null)
                {
                    Debug.LogWarning("[Lobby] Missing prefab/parent for room UI.");
                    continue;
                }
                var go = Instantiate(roomEntryPrefab, contentParent, false);
                go.transform.localScale = Vector3.one;
                go.SetActive(true);
                var entry = go.GetComponent<RoomListEntry>();
                if (entry != null) entry.SetInfo(name, info.PlayerCount, info.MaxPlayers, OnJoinButtonClicked, info.CustomProperties);
                roomEntries[name] = go;
            }
        }

        var rect = contentParent as RectTransform;
        if (rect != null) UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(rect);
    }






    private void OnJoinButtonClicked(string roomName)
    {
        Debug.Log("[Lobby] Join pressed for: " + roomName);

        if (!PhotonNetwork.IsConnectedAndReady || PhotonNetwork.NetworkingClient.Server != ServerConnection.MasterServer)
        {
            Debug.LogWarning("[Lobby] Not ready to join (not connected to MasterServer).");
            return;
        }

        PhotonNetwork.JoinRoom(roomName);
    }

    public void CreateRoomFromInput()
    {

        // cooldown

        if (Time.time - lastLeftTime < createCooldownSeconds)
        {
            float remain = createCooldownSeconds - (Time.time - lastLeftTime);
            Debug.LogWarning($"[Lobby] Create room blocked by cooldown. wait {Mathf.CeilToInt(remain)}s");
            if (createCooldownText != null) createCooldownText.text = $"������� ������� ����� ����� {Mathf.CeilToInt(remain)} �.";
            return;
        }

        string name = createRoomInput != null && !string.IsNullOrEmpty(createRoomInput.text)
            ? createRoomInput.text
            : $"Room_{UnityEngine.Random.Range(1000, 9999)}";


        //password

        string pwHash = null;
        bool pwProtected = false;
        if (createPasswordEnabled && createRoomPasswordInput != null)
        {
            string pw = createRoomPasswordInput.text;
            if (!string.IsNullOrEmpty(pw))
            {
                pwHash = ComputeSHA256Hash(pw);
                pwProtected = true;
            }
        }

        if (!PhotonNetwork.IsConnectedAndReady || PhotonNetwork.NetworkingClient.Server != ServerConnection.MasterServer)
        {
            Debug.LogWarning("[Lobby] Not connected/ready -> queuing creation and connecting/joining lobby.");
            pendingRoomToCreate = name;
            CreateLocalPendingEntry(name, pwProtected, pwHash);

            if (!PhotonNetwork.IsConnected) PhotonNetwork.ConnectUsingSettings();
            else PhotonNetwork.JoinLobby();

            return;
        }

        CreateLocalPendingEntry(name, pwProtected, pwHash);
        CreateRoomInternal(name, pwProtected, pwHash);
    }

    private void CreateRoomInternal(string name, bool pwProtected, string pwHash)
    {
        var roomProps = new Hashtable
        {
            { "creatorName", PhotonNetwork.NickName ?? "Host" },
            { "creatorActor", PhotonNetwork.LocalPlayer.ActorNumber }
        };
        for (int i = 1; i <= 12; i++) roomProps[$"slot_{i}"] = 0;

        if (pwProtected)
        {
            roomProps["pwProtected"] = true;
            roomProps["pwHash"] = pwHash ?? "";
        }

        var ro = new RoomOptions
        {
            MaxPlayers = 12,
            IsVisible = true,
            IsOpen = true,
            CustomRoomProperties = roomProps,
            CustomRoomPropertiesForLobby = pwProtected
                ? new string[] { "pwProtected", "pwHash", "creatorName", "creatorActor" }
                : new string[] { "creatorName", "creatorActor" }
        };

        ro.EmptyRoomTtl = 0;
        ro.PlayerTtl = 0;

        PhotonNetwork.CreateRoom(name, ro, TypedLobby.Default);
    }

    private void CreateLocalPendingEntry(string name, bool pwProtected, string pwHash)
    {
        if (roomEntries.ContainsKey(name)) return;
        if (roomEntryPrefab == null || contentParent == null) return;

        pendingLocalEntry = Instantiate(roomEntryPrefab, contentParent, false);
        pendingLocalEntry.transform.localScale = Vector3.one;
        var entryScript = pendingLocalEntry.GetComponent<RoomListEntry>();
        if (entryScript != null)
        {
            var localProps = new Hashtable { { "pwProtected", pwProtected } };
            if (pwProtected) localProps["pwHash"] = pwHash ?? "";
            entryScript.SetInfo(name, 1, 12, OnJoinButtonClicked, localProps);
        }
        roomEntries[name] = pendingLocalEntry;

        var rect = contentParent as RectTransform;
        if (rect != null) UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(rect);
    }

    public override void OnCreateRoomFailed(short returnCode, string message)
    {
        Debug.LogWarning($"[LobbyManager] Create room failed: {message} ({returnCode})");

        if (!string.IsNullOrEmpty(pendingRoomToCreate) && roomEntries.TryGetValue(pendingRoomToCreate, out GameObject go))
        {
            Destroy(go);
            roomEntries.Remove(pendingRoomToCreate);
        }

        pendingRoomToCreate = null;
        pendingLocalEntry = null;
    }

    public override void OnJoinedRoom()
    {
        Debug.Log($"[LobbyManager] OnJoinedRoom: {PhotonNetwork.CurrentRoom?.Name}");

        if (pendingLocalEntry != null)
        {
            try
            {
                string rm = null;
                foreach (var kv in roomEntries)
                {
                    if (kv.Value == pendingLocalEntry) { rm = kv.Key; break; }
                }
                if (!string.IsNullOrEmpty(rm)) roomEntries.Remove(rm);
            }
            catch { }
            Destroy(pendingLocalEntry);
            pendingLocalEntry = null;
        }

        if (!SceneLoadGuard.IsSceneLoading)
        {
            SceneLoadGuard.SetLoading("JoinedRoom -> Load Game scene");
            PhotonNetwork.LoadLevel("Room");
        }
        else
        {
            Debug.Log("[LobbyManager] SceneLoadGuard is set � scheduling retry to load Game scene.");
            StartCoroutine(RetryLoadWhenGuardClears("Room", 8f));
        }
    }

    private IEnumerator RetryLoadWhenGuardClears(string sceneName, float timeoutSeconds = 8f)
    {
        float t = 0f;
        while (SceneLoadGuard.IsSceneLoading && t < timeoutSeconds)
        {
            t += Time.deltaTime;
            yield return null;
        }

        if (!SceneLoadGuard.IsSceneLoading)
        {
            Debug.Log("[LobbyManager] Guard cleared � loading scene: " + sceneName);
            SceneLoadGuard.SetLoading("JoinedRoom -> Load Game scene (retry)");
            PhotonNetwork.LoadLevel(sceneName);
        }
        else
        {
            Debug.LogWarning("[LobbyManager] RetryLoadWhenGuardClears timed out. Forcing Menu reload to recover.");
            SceneLoadGuard.ClearLoading();
            SceneManager.LoadScene("lobby");
        }
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        Debug.Log($"[LobbyManager] PlayerLeftRoom {otherPlayer.NickName} ({otherPlayer.ActorNumber})");
    }

    public override void OnLeftRoom()
    {
        lastLeftTime = Time.time;

        if (createCooldownText != null && createCooldownText.gameObject != null)
        {
            createCooldownText.gameObject.SetActive(true);
        }

        if (cooldownCoroutine != null) StopCoroutine(cooldownCoroutine);
        cooldownCoroutine = StartCoroutine(CooldownDisplayRoutine());

        if (!string.IsNullOrEmpty(pendingRoomToCreate) && roomEntries.TryGetValue(pendingRoomToCreate, out GameObject go) && go != null)
        {
            Destroy(go);
            roomEntries.Remove(pendingRoomToCreate);
        }
        pendingRoomToCreate = null;
        pendingLocalEntry = null;
    }

    private System.Collections.IEnumerator CooldownDisplayRoutine()
    {
        if (createCooldownText != null && createCooldownText.gameObject != null)
            createCooldownText.gameObject.SetActive(true);

        while (Time.time - lastLeftTime < createCooldownSeconds)
        {
            float remaining = createCooldownSeconds - (Time.time - lastLeftTime);
            if (createCooldownText != null)
                createCooldownText.text = $"Cooldown: {Mathf.CeilToInt(remaining)} ";
            yield return new WaitForSeconds(1f);
        }

        if (createCooldownText != null)
        {
            createCooldownText.text = "";
            createCooldownText.gameObject.SetActive(false);
        }

        cooldownCoroutine = null;
    }

    private void UpdateCooldownTextImmediate()
    {
        if (Time.time - lastLeftTime < createCooldownSeconds)
        {
            float remaining = createCooldownSeconds - (Time.time - lastLeftTime);
            if (createCooldownText != null)
            {
                createCooldownText.text = $"Cooldown: {Mathf.CeilToInt(remaining)} ";
                createCooldownText.gameObject.SetActive(true);
            }
            if (cooldownCoroutine == null) cooldownCoroutine = StartCoroutine(CooldownDisplayRoutine());
        }
        else
        {
            if (createCooldownText != null && createCooldownText.gameObject != null)
                createCooldownText.gameObject.SetActive(false);
        }
    }

    private void ClearAllRoomEntries()
    {
        foreach (var kv in roomEntries)
        {
            if (kv.Value != null) Destroy(kv.Value);
        }
        roomEntries.Clear();
    }





    private string ComputeSHA256Hash(string input)
    {
        if (string.IsNullOrEmpty(input)) return null;
        using (SHA256 sha = SHA256.Create())
        {
            byte[] data = Encoding.UTF8.GetBytes(input);
            byte[] hash = sha.ComputeHash(data);
            StringBuilder sb = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash) sb.AppendFormat("{0:x2}", b);
            return sb.ToString();
        }
    }
}
